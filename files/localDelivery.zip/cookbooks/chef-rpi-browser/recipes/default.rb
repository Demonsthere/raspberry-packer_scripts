execute 'apt-get update'

[node['chef-rpi-browser']['browser'], 'zip', 'gnash-common', 'gnash', 'browser-plugin-gnash', 'git', 'make'].each do |pkg_name|
  package pkg_name do
    action :upgrade
  end
end

git node['chef-rpi-browser']['git'] do
  repository 'https://github.com/emsearcy/firefox-tabslideshow.git'
  user node['chef-rpi-browser']['userName']
  enable_submodules true
  action :sync
end

execute 'make' do
  user node['chef-rpi-browser']['userName']
  cwd node['chef-rpi-browser']['git']
end

cookbook_file 'extractExtension.sh' do
  user node['chef-rpi-browser']['userName']
  path "#{node['chef-rpi-browser']['homePath']}/extractExtension.sh"
  mode '0755'
end

execute 'extract the Extension' do
  cwd node['chef-rpi-browser']['homePath']
  command 'sh extractExtension.sh'
  not_if { ::File.directory?('/usr/lib/firefox/mozilla.cfg') }
end

cookbook_file 'autoconfig.js' do
  path '/usr/lib/firefox/defaults/pref/autoconfig.js'
end

cookbook_file 'mozilla.cfg' do
  path '/usr/lib/firefox/mozilla.cfg'
end

['.config', '.config/upstart'].each do |dir|
  directory "#{node['chef-rpi-browser']['homePath']}/#{dir}" do
    owner node['chef-rpi-browser']['userName']
    group node['chef-rpi-browser']['userName']
    action :create
    recursive true
  end
end

cookbook_file 'firefox.conf' do
  path "#{node['chef-rpi-browser']['homePath']}/.config/upstart/firefox.conf"
  only_if { ::File.directory?("#{node['chef-rpi-browser']['homePath']}/.config/upstart") }
end
