#!/bin/bash -x
mkdir temp
cp tabslideshow/*.xpi temp
cd temp
unzip *.xpi
HASH_NAME=$(cat install.rdf | grep "<em:id>" | head -n 1 | sed 's/^.*>\(.*\)<.*$/\1/g')
rm -f *.xpi
cd ..
mv temp/ $HASH_NAME/
mv $HASH_NAME /usr/lib/firefox/browser/extensions/