default['chef-rpi-browser'].tap do |it|
  it['userName'] = 'vagrant'
  it['homePath'] = "/home/#{node['chef-rpi-browser']['userName']}"
  it['git'] = "#{node['chef-rpi-browser']['homePath']}/tabslideshow"
  it['browser'] = 'firefox'
  it['machineType'] = 'testing'
end
