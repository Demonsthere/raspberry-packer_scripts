# Chef-rpi-Browser

Single recipe cookbook designed to download a chosen browser (preferably firefox or iceweasel due to the lack of support of unantented extension installation of chrome) together with a set of extension and configuration files.

## Installed extenstions

The extension installed currently is firefox-tabslideshow (https://github.com/emsearcy/firefox-tabslideshow.git) which allows the browser to autamitically change tabs every x seconds. This can be used for an automaties slideshow of dashboards

## Configuration files

The cookbook uses the updated method of predefined configuration that inserts a file (autoconfig.js) to firefox telling it to override it's configuration with the content of the second file (mozilla.cfg)m in which the valid configuration is stored.
The chosen pages are: 

+	http://acid-jkm.yrdrt.fra.hybris.com:8080/view/DB-dashboard
+	http://dash.yrd.fra.hybris.com/#/dashboard/db/databases-pool-usage
+	http://acid-mesos-master.yrdrt.fra.hybris.com:5050
+	http://dash.yrd.fra.hybris.com/#/dashboard/db/Bamboo%20Agents%20Load
+	http://acid-jkm.yrdrt.fra.hybris.com:8080/view/RaspberryPI/
+	http://dash.yrd.fra.hybris.com/#/dashboard/db/dam-monitoring
+	http://dash.yrd.fra.hybris.com/#/dashboard/db/acidjks

## Packages

To allow the action, several more packages are needed to be installed. The most important of them are:

+	Gnash Flash Player Browser Plugin
+	Git

## Unatended instalation

Thanks to the new framework of preferences setting, the headless run of the browser could be removed, simplifing the whole process.