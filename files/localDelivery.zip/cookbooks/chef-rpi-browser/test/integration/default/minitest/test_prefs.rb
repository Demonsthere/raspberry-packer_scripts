require 'minitest/autorun'
require 'busser/rubygems'

describe 'chef-rpi-browser::default' do
  it 'test prefs entry' do
    # Given:
    result = %x(less /usr/lib/firefox/mozilla.cfg)
    puts result

    # Expect:
    assert result.include?('pref("tabslideshow.refresh", true);')
    assert result.include?('pref("tabslideshow.start", true);')
    assert result.include?('lockPref("extensions.autoDisableScopes", 0);')
  end
end
