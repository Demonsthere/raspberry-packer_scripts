# chef-rpi-emulation

Simple cookbooks which downloads a gitball and compiles the PCSX emulator, which is should be able to emulate the PlayStation 1. 
Additionally, it downloads the ready to use binaries of Amiga and Nintendo emulators with 2 games for demonstration of the last one.
