#
# Cookbook Name:: chef-rpi-emulation
# Recipe:: default
#
# Copyright (c) 2015 The Authors, All Rights Reserved.
execute 'apt-get update'

['libpng-dev', 'libsdl1.2-dev', 'git', 'libguichan-sdl-0.8.1-1', 'libsdl-ttf2.0-0', 'zip', 'unzip'].each do |pkg|
  package pkg do
    action :upgrade
  end
end

git "#{node['chef-rpi-emulation']['homePath']}/pcsx_rearmed" do
  repository 'https://github.com/notaz/pcsx_rearmed.git'
  user node['chef-rpi-emulation']['userName']
  enable_submodules true
  action :sync
end

['./configure --sound-drivers=sdl'].each do |cmd|
  execute cmd do
    cwd "#{node['chef-rpi-emulation']['homePath']}/pcsx_rearmed"
    not_if { node['chef-rpi-emulation']['machineType'].include? 'testing' }
    user node['chef-rpi-emulation']['userName']
  end
end

remote_file "#{node['chef-rpi-emulation']['homePath']}/uae4all2-rpi-chips-0_5.bz2" do
  source 'http://fdarcel.free.fr/uae4all2-rpi-chips-0_5.bz2'
  owner user node['chef-rpi-emulation']['userName']
  mode '0644'
  action :create
end

remote_file "#{node['chef-rpi-emulation']['homePath']}/pisnes.zip" do
  source 'http://downloads.sourceforge.net/project/pisnes/pisnes.zip?r=http%3A%2F%2Fsourceforge.net%2Fprojects%2Fpisnes%2F&ts=1438776084&use_mirror=garr'
  owner user node['chef-rpi-emulation']['userName']
  mode '0644'
  action :create
end

['tar jxf *.bz2', 'unzip pisnes.zip -d snes'].each do |cmd|
  execute cmd do
    cwd node['chef-rpi-emulation']['homePath']
    user node['chef-rpi-emulation']['userName']
  end
end

['DragonView.zip', 'LegendofZelda.zip'].each do |file|
  cookbook_file file do
    path "#{node['chef-rpi-emulation']['homePath']}/snes/roms/#{file}"
    user node['chef-rpi-emulation']['userName']
  end
end

remote_file "#{node['chef-rpi-emulation']['homePath']}/snes/roms/Mortal.zip" do
  source 'https://www.loveroms.com/r/Super%20Nintendo/L-O/Mortal%20Kombat%20(U).zip'
  owner user node['chef-rpi-emulation']['userName']
  mode '0644'
  action :create
end

remote_file "#{node['chef-rpi-emulation']['homePath']}/snes/roms/DungeonMaster.zip" do
  source 'https://www.loveroms.com/r/Super%20Nintendo/D-F/Dungeon%20Master%20(U).zip'
  owner user node['chef-rpi-emulation']['userName']
  mode '0644'
  action :create
end

['DragonView.zip', 'LegendofZelda.zip', 'Mortal.zip', 'DungeonMaster.zip'].each do |arch|
  execute 'unzip gameFile' do
    cwd "#{node['chef-rpi-emulation']['homePath']}/snes/roms"
    user node['chef-rpi-emulation']['userName']
    command "unzip #{arch}"
  end
end
