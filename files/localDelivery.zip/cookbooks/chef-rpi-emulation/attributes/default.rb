default['chef-rpi-emulation'].tap do |it|
  it['userName'] = 'vagrant'
  it['homePath'] = "/home/#{node['chef-rpi-emulation']['userName']}"
  it['machineType'] = 'testing'
end
