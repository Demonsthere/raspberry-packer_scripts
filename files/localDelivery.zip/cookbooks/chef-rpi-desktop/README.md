# chef-rpi-desktop

Single recipe cookbooks which aims to supply a node with a set of basic desktop packages (network gui, terminal, drivers, etc.), as well as a set of special drivers for the Pi platform (xserver boost, some binaries) and a set of configuration files to disable screen blanking. 