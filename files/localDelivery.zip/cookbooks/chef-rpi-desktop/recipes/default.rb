#
# Cookbook Name:: chef-rpi-desktop
# Recipe:: default
#
# Copyright (c) 2015 The Authors, All Rights Reserved.
execute 'apt-get update'

['linux-firmware', 'apt-transport-https', 'wpasupplicant', 'wireless-tools', 'upower', 'lxterminal', 'network-manager', 'upstart'].each do |pkg|
  package pkg do
    action :install
  end
end

['libraspberrypi-bin', 'libraspberrypi-dev', 'libraspberrypi-bin-nonfree', 'xserver-xorg-video-fbturbo'].each do |pkg|
  package pkg do
    action :upgrade
    not_if { node['chef-rpi-desktop']['machineType'].include? 'testing' }
  end
end

cookbook_file 'config' do
  mode '0644'
  path '/etc/kbd/config'
end

file 'etc/network/interfaces' do
  action :create
  content '# interfaces(5) file used by ifup(8) and ifdown(8)
    # Include files from /etc/network/interfaces.d:
    source-directory /etc/network/interfaces.d

    # The loopback network interface
    auto lo
    iface lo inet loopback'
end

cookbook_file 'lightdm.conf' do
  mode '0644'
  path '/etc/lightdm/lightdm.conf'
  only_if { ::File.directory? '/etc/lightdm' }
end
