default['chef-rpi-desktop'].tap do |it|
  it['userName'] = 'vagrant'
  it['homePath'] = "/home/#{node['chef-rpi-desktop']['userName']}"
  it['machineType'] = 'testing'
end
