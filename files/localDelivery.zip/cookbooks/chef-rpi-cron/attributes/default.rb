default['chef-rpi-cron'].tap do |it|
  it['userName'] = 'vagrant'
  it['homePath'] = "/home/#{node['chef-rpi-cron']['userName']}"
  it['machineType'] = 'testing'
end
