#!/bin/bash
PROGRAM="iceweasel"
if pgrep $PROGRAM > /dev/null 2>&1
        then
                echo "Program is running, all is fine"
        else    echo "Iceweasel crashed!" && eval "$PROGRAM"
fi