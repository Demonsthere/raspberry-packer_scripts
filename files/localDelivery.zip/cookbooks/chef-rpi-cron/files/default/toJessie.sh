#!/bin/bash
cat /etc/apt/sources.list
sudo sed -i 's/wheezy/jessie/g' /etc/apt/sources.list
cat /etc/apt/sources.list