require 'minitest/autorun'
require 'busser/rubygems'

describe 'chef-rpi-cron::default' do
  it 'test crontab entry' do
    # Given:
    result = %x(sudo crontab -u root -l)
    puts result

    # Expect:
    assert result.include?('# Chef Name: planned shutdown')
  end
end
