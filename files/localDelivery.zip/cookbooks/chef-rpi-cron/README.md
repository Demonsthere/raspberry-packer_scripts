# chef-rpi-cron

Very simple cookbook that adds two crontab entries.

The first shutdown the system at every weekday at 17:15
The second one performs a full system update (update, upgrade, dist-upgrade, autoclean, autoremove) at the reboot of the system
