#
# Cookbook Name:: chef-rpi-cron
# Recipe:: default
#
# Copyright (c) 2015 The Authors, All Rights Reserved.
cron 'planned shutdown' do
  minute '15'
  hour '17'
  weekday '1-5'
  action :create
  command 'shutdown -hR 1 &'
end

['reRun.sh', 'update.sh', 'toJessie.sh'].each do |cmd|
  cookbook_file cmd do
    mode '0755'
    path "#{node['chef-rpi-cron']['homePath']}/#{cmd}"
    user node['chef-rpi-cron']['userName']
    not_if { node['chef-rpi-cron']['machineType'].include? 'ubuntu' }
  end
end
